import pymysql
import yaml
from pathlib import Path


class baseObject:
    def __init__(self):
        self.conn = None
        self.cur = None
        self.data = []
        self.setup()

    def setup(self):
        config = yaml.safe_load(Path("config.yml").read_text())
        print("Config Loaded:", config)  
        self.config = config
        self.tn = self.config['tables'][type(self).__name__.lower()]  
        self.conn = None
        self.cur = None
        self.pk = None
        self.fields = []
        self.errors = []
        self.data = []
        self.establishConnection()
        self.getFields()
        print("Fields Retrieved:", self.fields)  
    def establishConnection(self):
        config = self.config
        self.conn = pymysql.connect(host=config['db']['host'], port=config['db']['port'], user=config['db']['user'],
                                     passwd=config['db']['passwd'], db=config['db']['db'], autocommit=True)
        self.cur = self.conn.cursor(pymysql.cursors.DictCursor)

    def set(self, d):
        for field in self.fields:
            if field not in d and field != self.pk:  
                raise ValueError(f"Missing required field: {field}")
        self.data.append(d)
        print("Data Set for Insertion:", d)  

    def getFields(self):
        sql = f'''DESCRIBE `{self.tn}`;'''
        self.cur.execute(sql)
        self.fields = []  
        for row in self.cur:
            print("Field Row:", row) 
            if row['Extra'] == 'auto_increment':
                self.pk = row['Field']
            else:
                self.fields.append(row['Field'])
        print("Fields Retrieved After Refresh:", self.fields)

    def insert(self, n=0):
        count = 0
        vals = []
        print("Data being inserted:", self.data[n])  
        sql = f"INSERT INTO `{self.tn}` ("
        for field in self.fields:
            if field in self.data[n]:  
                sql += f"`{field}`,"
                vals.append(self.data[n][field])
                count += 1
        sql = sql.rstrip(',') + ') VALUES (' + ("%s," * count).rstrip(',') + ');'
        print("Generated SQL:", sql)  
        print("Values:", vals)  
        self.cur.execute(sql, vals)
        self.data[n][self.pk] = self.cur.lastrowid

    def createBlank(self):
        d = {field: '' for field in self.fields}
        self.set(d)

    def getById(self, id):
        sql = f"SELECT * FROM `{self.tn}` WHERE `{self.pk}` = %s"
        self.cur.execute(sql, (id,))
        self.data = [row for row in self.cur]

    def getAll(self):
        sql = f"SELECT * FROM `{self.tn}`"
        self.cur.execute(sql)
        self.data = [row for row in self.cur]

    def truncate(self):
        sql = f"TRUNCATE TABLE `{self.tn}`"
        self.cur.execute(sql)

    def getByField(self, field, val):
        sql = f"SELECT * FROM `{self.tn}` WHERE `{field}` = %s"
        self.cur.execute(sql, (val,))
        self.data = [row for row in self.cur]

    def update(self, n=0):
        vals = []
        fvs = ''
        for field in self.fields:
            if field in self.data[n].keys():
                fvs += f"`{field}`=%s,"
                vals.append(self.data[n][field])
        fvs = fvs.rstrip(',')
        sql = f"UPDATE `{self.tn}` SET {fvs} WHERE `{self.pk}` = %s"
        vals.append(self.data[n][self.pk])
        self.cur.execute(sql, vals)

    def deleteById(self, id):
        sql = f"DELETE FROM `{self.tn}` WHERE `{self.pk}` = %s"
        self.cur.execute(sql, (id,))
