from flask import Flask, render_template, request, session, redirect
from flask_session import Session
from datetime import timedelta
from datetime import datetime
from user import User
from sources import Sources
from transfer import Transfer
from transaction import Transaction
from dispute import Dispute
import time
import json


app = Flask(__name__)
app.config['SECRET_KEY'] = '56hdtryhRTg'
app.config['SESSION_PERMANENT'] = True
app.config['SESSION_TYPE'] = 'filesystem'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=5)
sess = Session()
sess.init_app(app)

# Homepage
@app.route('/')
def home():
    return render_template('home.html')

# Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        print("Form Data Received:", request.form)
        u = User()
        username = request.form.get('name')
        password = request.form.get('password')
        print("Login attempt with Username:", username)
        if u.tryLogin(username, password):
            user_data = u.data[0]
            if user_data['role'] == 'customer':  
                session['user'] = user_data
                session['active'] = time.time()
                print("Login successful for Customer Username:", username)
                return redirect('/dashboard')
            else:
                print("Access Denied: Not a customer.")
                return render_template('login.html', title='Login', msg='Access denied.')
        else:
            print("Login failed for Username:", username)
            return render_template('login.html', title='Login', msg='Incorrect username or password.')
    return render_template('login.html', title='Customer Login', msg='Type your email and password to continue.')


# Logout
@app.route('/logout')
def logout():
    session.pop('user', None)
    session.pop('active', None)
    return render_template(
        'ok_dialog.html',
        msg="You have logged out successfully!",
        button_label="Go to Login",
        button_link="/login"
    )

# Register
from datetime import datetime  # Ensure this import is present

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        u = User()
        hashed_password = u.hashPassword(request.form['password'])  
        d = {
            'UserName': request.form['username'],
            'Password': hashed_password,
            'FirstName': request.form['first_name'],
            'LastName': request.form['last_name'],
            'Email': request.form['email'],
            'PhoneNumber': request.form.get('phone_number', None),
            'Address': request.form.get('address', None),
            'MiddleName': request.form.get('middle_name', None),
            'role': 'customer',
            'CreatedAt': datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # Add current timestamp
        }
        print("Data to Insert in Register:", d)  
        try:
            u.set(d)
            u.insert()
        except Exception as e:
            print("Error:", e)
            return render_template('register.html', title='Register', msg=f"Registration failed: {e}")
        return render_template(
            'ok_dialog.html',
            msg="User registered successfully! Please login.",
            button_label="Go to Login",
            button_link="/login"
        )
    return render_template('register.html', title='Register')


# Admin Login
@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        u = User()
        username = request.form.get('username')
        password = request.form.get('password')

        if u.tryLogin(username, password):
            user_data = u.data[0]
            if user_data.get('role') == 'admin':
                session['user'] = user_data
                session['active'] = time.time()
                return redirect('/admin_dashboard')
            else:
                return render_template('admin_login.html', error="Access denied. Only admins can log in.")
        else:
            return render_template('admin_login.html', error="Invalid credentials.")
    return render_template('admin_login.html')



@app.route('/admin_dashboard', methods=['GET'])
def admin_dashboard():
    if 'user' not in session or session['user'].get('role') != 'admin':
        return redirect('/admin_login')

    u = User()
    t = Transaction()
    d = Dispute()

    
    unique_usernames = u.getUniqueUsernames()  
    total_transactions = t.getTotalTransactions()  
    pending_disputes = d.getPendingDisputes() 


    weekly_transactions = t.getWeeklyTransactionCount()  


    graph_data = {
        "data": [
            {
                "x": [f"Week {item['Week']}" for item in weekly_transactions],  
                "y": [item['Count'] for item in weekly_transactions],  
                "type": "bar",
                "marker": {
                    "color": "rgba(153, 102, 255, 0.6)",
                    "line": {"color": "rgba(153, 102, 255, 1)", "width": 1}
                }
            }
        ],
        "layout": {
            "title": "Weekly Transactions",
            "xaxis": {"title": "Week"},
            "yaxis": {"title": "Number of Transactions"}
        }
    }


    graph_json = json.dumps(graph_data)

    return render_template(
        'admin_dashboard.html',
        unique_usernames=unique_usernames,
        total_transactions=total_transactions,
        disputes=pending_disputes,
        graph_json=graph_json
    )








@app.route('/admin/dispute/<int:dispute_id>/<action>', methods=['POST'])
def manage_dispute(dispute_id, action):
    if 'user' not in session or session['user']['role'] != 'admin':
        return {"error": "Unauthorized access"}, 403

    # Retrieve admin reply
    admin_reply = request.json.get('admin_reply', '').strip()
    if not admin_reply:
        return {"error": "Admin reply cannot be empty"}, 400

    # Update dispute status
    d = Dispute()
    if action in ['approve', 'reject']:
        new_status = 'Approved' if action == 'approve' else 'Rejected'
        query = """
            UPDATE disputes 
            SET Status = %s, State = 'Closed', AdminReply = %s, DisputeClosedDate = %s
            WHERE DisputeID = %s
        """
        values = (new_status, admin_reply, datetime.now(), dispute_id)
        try:
            d.cur.execute(query, values)
            d.conn.commit()
            return {"success": f"Dispute {action}d successfully"}
        except Exception as e:
            print("Error updating dispute:", e)
            return {"error": "Failed to update dispute."}, 500
    return {"error": "Invalid action"}, 400




# Dashboard
@app.route('/dashboard')
def dashboard():
    if 'user' not in session:  
        return redirect('/login')  
    user = session['user']
    return render_template('dashboard.html', user=user)  

# Sources Management
@app.route('/sources')
def sources():
    if 'user' not in session:
        return redirect('/login')
    s = Sources()
    user_id = session['user']['UserID']
    sources = s.getAllByUser(user_id)  
    return render_template('sources.html', sources=sources)


@app.route('/sources/add', methods=['GET', 'POST'])
def add_sources():
    if 'user' not in session:
        return redirect('/login')
    if request.method == 'POST':
        expiry_raw = request.form.get('expiry')
        expiry_formatted = None
        if expiry_raw:
            try:
                expiry_formatted = datetime.strptime(expiry_raw, '%m/%y').strftime('%Y-%m-%d')
            except ValueError:
                return render_template('add_sources.html', msg="Invalid Expiry Date. Please use MM/YY format.")

        source_data = {
            'UserID': session['user']['UserID'],
            'Type': request.form.get('type'),
            'BankAccountNumber': request.form.get('bank_account_number') or None,
            'RoutingNumber': request.form.get('routing_number') or None,
            'CardNumber': request.form.get('card_number') or None,
            'CVV': request.form.get('cvv') or None,
            'Expiry': expiry_formatted,
            'balance': float(request.form.get('balance', 0))  
        }
        print("Source Data to be Added:", source_data)
        s = Sources()
        try:
            s.set(source_data)
            s.insert()
            return redirect('/sources')
        except Exception as e:
            print("Error Adding Source:", e)
            return render_template('add_sources.html', msg=f"Error Adding Source: {e}")
    return render_template('add_sources.html')

@app.route('/sources/delete', methods=['GET', 'POST'])
def delete_sources():
    if 'user' not in session:
        return redirect('/login')

    s = Sources()
    user_id = session['user']['UserID']
    sources = s.getAllByUser(user_id)  

    if request.method == 'POST':
        source_id = request.form.get('source_id')

        if not source_id:
            return render_template('error_dialog.html', msg="No source selected for deletion.")

        try:
            
            source_id = int(source_id)

            
            s.getByField('SourceID', source_id)
            if not s.data:
                return render_template('error_dialog.html', msg="Source not found.")

            is_primary = s.data[0]['IsPrimary']

            
            s.deleteById(source_id)

            
            if is_primary:
                remaining_sources = s.getAllByUser(user_id)  
                if remaining_sources:
                    
                    new_primary_source_id = remaining_sources[0]['SourceID']
                    sql_set_primary = "UPDATE sources SET IsPrimary = 1 WHERE SourceID = %s"
                    s.cur.execute(sql_set_primary, (new_primary_source_id,))
                    s.conn.commit()

            return redirect('/sources')  

        except ValueError:
            return render_template('error_dialog.html', msg="Invalid source ID.")
        except Exception as e:
            return render_template('error_dialog.html', msg=f"An error occurred: {str(e)}")

    return render_template('delete_sources.html', sources=sources)




@app.route('/sources/set_primary', methods=['POST'])
def set_primary_source():
    if 'user' not in session:
        return redirect('/login')
    
    source_id = request.form.get('source_id')
    user_id = session['user']['UserID']

    s = Sources()

    
    s.getByField('SourceID', source_id)
    if not s.data or s.data[0]['UserID'] != user_id:
        return render_template('error_dialog.html', msg="Invalid source.")

    
    sql_reset = "UPDATE sources SET IsPrimary = 0 WHERE UserID = %s"
    s.cur.execute(sql_reset, (user_id,))

    sql_set_primary = "UPDATE sources SET IsPrimary = 1 WHERE SourceID = %s"
    s.cur.execute(sql_set_primary, (source_id,))

    return redirect('/sources')







# Transactions
@app.route('/transactions', methods=['GET'])
def transactions():
    if 'user' not in session:
        return redirect('/login')

    user_name = session['user']['UserName']  

    t = Transaction()
    transactions = t.getRecentByUser(user_name, limit=5)

    for index, transaction in enumerate(transactions):
        transaction['DisplayID'] = index + 1  

        
        sql = "SELECT Status, AdminReply FROM disputes WHERE TransactionID = %s"
        t.cur.execute(sql, (transaction['TransactionID'],))
        dispute = t.cur.fetchone()

        if dispute:
            transaction['DisputeStatus'] = dispute['Status']  
            transaction['AdminReply'] = dispute['AdminReply']  
        else:
            transaction['DisputeStatus'] = None
            transaction['AdminReply'] = None

    print("Transactions Sent to Template:", transactions)  

    return render_template('transactions.html', transactions=transactions)




# All Transactions 
@app.route('/transactions/all', methods=['GET', 'POST'])
def all_transactions():
    if 'user' not in session:
        return redirect('/login')

    user_name = session['user']['UserName']  
    t = Transaction()

    transactions = t.getAllByUser(user_name)
    print("All Transactions Sent to Template:", transactions)

    return render_template('all_transactions.html', transactions=transactions)


# Raise a dispute
@app.route('/transactions/dispute/<int:transaction_id>', methods=['GET', 'POST'])
def raise_dispute(transaction_id):
    if 'user' not in session:
        return redirect('/login')

    t = Transaction()
    t.getByField('TransactionID', transaction_id)

    if not t.data:
        return render_template('error_dialog.html', msg="Transaction not found.")

    if request.method == 'POST':
        message = request.form.get('message', '').strip()
        if not message:
            return render_template('error_dialog.html', msg="Dispute message cannot be empty.")

        user_id = session['user']['UserID']
        query = """
            INSERT INTO disputes (TransactionID, UserID, Message, Status, State, DisputeRaisedDate)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        values = (transaction_id, user_id, message, 'Pending', 'Open', datetime.now())

        try:
            t.cur.execute(query, values)
            t.conn.commit()
            return render_template('ok_dialog.html', msg="Dispute raised successfully.")
        except Exception as e:
            print("Error inserting dispute:", e)
            return render_template('error_dialog.html', msg="An error occurred while raising the dispute.")

    return render_template('raise_dispute.html', transaction=t.data[0])




@app.route('/manage_disputes', methods=['GET', 'POST'])
def manage_disputes():
    if 'user' not in session or session['user']['Role'] != 'admin':
        return redirect('/admin_login')

    disputes = Dispute()

    if request.method == 'POST':
        dispute_id = request.form.get('dispute_id')
        action = request.form.get('action')  

        if action in ['Approve', 'Decline']:
            disputes.updateDisputeStatus(dispute_id, action)
            return redirect('/manage_disputes')

    pending_disputes = disputes.getPendingDisputes()
    return render_template('manage_disputes.html', disputes=pending_disputes)


@app.route('/list_users')
def list_users():
    if 'user' not in session or session['user']['Role'] != 'admin':
        return redirect('/admin_login')

    u = User()
    users = u.getAll()
    return render_template('list_users.html', users=users)


@app.route('/transactions/stats')
def transaction_stats():
    if 'user' not in session:
        return redirect('/login')
    return render_template('transaction_stats.html')

@app.route('/transactions/dispute', methods=['POST'])
def dispute_transaction():
    if 'user' not in session:
        return redirect('/login')
    transaction_id = request.form.get('transaction_id')
    return render_template(
        'ok_dialog.html',
        msg="Dispute raised successfully!",
        button_label="View Transactions",
        button_link="/transactions"
    )

# Transfers
@app.route('/transfer', methods=['GET', 'POST'])
def transfer():
    if 'user' not in session:
        return redirect('/login')

    s = Sources()
    u = User()
    user_id = session['user']['UserID']
    user_name = session['user']['UserName']  
    sources = s.getAllByUser(user_id)  

    if request.method == 'POST':
        receiver_email = request.form.get('receiver_email')
        amount = float(request.form.get('amount', 0))
        primary_source_id = request.form.get('primary_source')
        secondary_source_id = request.form.get('secondary_source')  
        if not primary_source_id or not receiver_email or amount <= 0:
            return render_template('error_dialog.html', msg="Invalid input. Please provide all required fields.")

        receiver = u.getByEmailCaseInsensitive(receiver_email)
        if not receiver:
            return render_template('error_dialog.html', msg="Receiver not found.")

        receiver_user = receiver[0]
        receiver_id = receiver_user['UserID']
        receiver_name = receiver_user['UserName']

        s.getByField('SourceID', primary_source_id)
        primary_source = s.data[0] if s.data else None

        if not primary_source:
            return render_template('error_dialog.html', msg="Primary source not found.")

        primary_balance = float(primary_source.get('balance', 0))
        
        secondary_balance = 0
        if secondary_source_id:
            s.getByField('SourceID', secondary_source_id)
            secondary_source = s.data[0] if s.data else None
            if not secondary_source:
                return render_template('error_dialog.html', msg="Secondary source not found.")
            secondary_balance = float(secondary_source.get('balance', 0))

        total_balance = primary_balance + secondary_balance
        if total_balance < amount:
            return render_template(
                'error_dialog.html', 
                msg=f"Insufficient funds. Available total balance: {total_balance}"
            )

        remaining_amount = amount
        if primary_balance >= remaining_amount:
            new_primary_balance = primary_balance - remaining_amount
            s.updateBalance(primary_source_id, new_primary_balance)
            remaining_amount = 0
        else:
            new_primary_balance = 0
            remaining_amount -= primary_balance
            s.updateBalance(primary_source_id, new_primary_balance)

        if remaining_amount > 0 and secondary_balance >= remaining_amount:
            new_secondary_balance = secondary_balance - remaining_amount
            s.updateBalance(secondary_source_id, new_secondary_balance)
            remaining_amount = 0

        t = Transaction()
        t.set({
            'SenderName': user_name,  
            'SenderAccNum': primary_source.get('BankAccountNumber', None),
            'SenderCardNo': primary_source.get('CardNumber', None),
            'ReceiverName': receiver_name,
            'ReceiverAccNum': None,  
            'ReceiverCardNo': None,  
            'AmountSent': amount,
            'AmountReceived': amount,  
            'TransactionDate': datetime.now().strftime('%Y-%m-%d'),
            'Status': 'Successful'
        })
        t.insert()

        return redirect('/transactions')

    return render_template('transfer.html', sources=sources)






@app.route('/transfer_secondary', methods=['POST'])
def transfer_secondary():
    if 'user' not in session:
        return redirect('/login')
    
    primary_source_id = int(request.form.get('primary_source_id'))
    secondary_source_id = int(request.form.get('secondary_source'))
    receiver_email = request.form.get('receiver_email')
    amount = float(request.form.get('amount'))
    remaining_amount = float(request.form.get('remaining_amount'))

    s = Sources()
    s.getById(primary_source_id)
    primary_source = s.data[0]
    primary_balance = float(primary_source['Balance'])

    s.getById(secondary_source_id)
    secondary_source = s.data[0]
    secondary_balance = float(secondary_source['Balance'])

    if primary_balance + secondary_balance < amount:
        
        return render_template('ok_dialog.html', msg="Transfer failed. Insufficient funds across both sources.")

    
    primary_source['Balance'] = 0  
    secondary_source['Balance'] -= remaining_amount

    s.set(primary_source)
    s.update()
    s.set(secondary_source)
    s.update()

    u = User()
    receiver = u.getByField('Email', receiver_email)[0]
    t = Transaction()
    t.set({
        'SenderUserID': session['user']['UserID'],
        'ReceiverUserID': receiver['UserID'],
        'Amount': amount,
        'Status': 'Success'
    })
    t.insert()

    return render_template('ok_dialog.html', msg="Transfer completed successfully!")


if __name__ == '__main__':
    app.run(host='127.0.0.1', debug=True)
