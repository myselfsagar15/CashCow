from baseObject import baseObject

class Sources(baseObject):
    def __init__(self):
        self.setup()

    def set(self, data):
        """Override the set method for specific validation."""
        required_fields = ['Type', 'balance']  
        if data['Type'] == 'Bank Account':
            required_fields.extend(['BankAccountNumber', 'RoutingNumber'])
        elif data['Type'] == 'Card':
            required_fields.extend(['CardNumber', 'CVV', 'Expiry'])

        
        formatted_data = {}
        for key in self.fields:  
            formatted_data[key] = data.get(key)

        
        for field in required_fields:
            if not formatted_data.get(field):
                raise ValueError(f"Missing required field: {field}")

        
        super().set(formatted_data)

    def getAllByUser(self, user_id):
        sql = f"SELECT * FROM `{self.tn}` WHERE `UserID` = %s"
        self.cur.execute(sql, (user_id,))
        self.data = []
        for row in self.cur:
            self.data.append(row)
        return self.data


    def deleteSourceAndReassignPrimary(self, source_id, user_id):
        
        sql_check = f"SELECT IsPrimary FROM `{self.tn}` WHERE `SourceID` = %s"
        self.cur.execute(sql_check, (source_id,))
        is_primary = self.cur.fetchone()

        
        sql_delete = f"DELETE FROM `{self.tn}` WHERE `SourceID` = %s"
        self.cur.execute(sql_delete, (source_id,))

        
        if is_primary and is_primary['IsPrimary'] == 1:
            sql_reassign = f"UPDATE `{self.tn}` SET `IsPrimary` = 1 WHERE `UserID` = %s LIMIT 1"
            self.cur.execute(sql_reassign, (user_id,))

        self.conn.commit()

    def getPrimarySource(self, user_id):
        """
        Fetch the primary source for a specific user.
        """
        sql = f"SELECT * FROM `{self.tn}` WHERE `UserID` = %s AND `IsPrimary` = 1"
        self.cur.execute(sql, (user_id,))
        self.data = self.cur.fetchone()  
        return self.data


    
    def updateBalance(self, source_id, new_balance):
        sql = "UPDATE sources SET Balance = %s WHERE SourceID = %s"
        self.cur.execute(sql, (new_balance, source_id))
