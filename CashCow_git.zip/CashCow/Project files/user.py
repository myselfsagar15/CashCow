import hashlib
from baseObject import baseObject

class User(baseObject):
    def __init__(self):
        self.setup()
        self.roles = [{'value':'admin', 'text':'admin'}, {'value':'employee', 'text':'employee'}, {'value':'customer', 'text':'customer'}]

    def hashPassword(self, password):
        return hashlib.md5(password.encode()).hexdigest()

    def tryLogin(self, username, password):
        hashed_password = self.hashPassword(password)  
        sql = f"SELECT * FROM `{self.tn}` WHERE `UserName` = %s AND `Password` = %s"
        print("Executing SQL:", sql)  
        print("With Values:", username, hashed_password)  
        self.cur.execute(sql, (username, hashed_password))
        self.data = []
        for row in self.cur:
            self.data.append(row)
        print("Data Retrieved:", self.data)  
        return len(self.data) > 0
    def getByEmailCaseInsensitive(self, email):
        sql = f"SELECT * FROM `{self.tn}` WHERE LOWER(`Email`) = LOWER(%s)"
        self.cur.execute(sql, (email,))
        self.data = self.cur.fetchall()
        return self.data
    def getTotalUsers(self):
        sql = "SELECT COUNT(*) as TotalUsers FROM users WHERE Role = 'user'"
        self.cur.execute(sql)
        return self.cur.fetchone()['TotalUsers']

    def getWeeklyUserCount(self):
        sql = """
            SELECT YEARWEEK(CreatedAt, 1) AS Week, COUNT(*) as Users
            FROM users
            WHERE role = 'customer'
            GROUP BY YEARWEEK(CreatedAt, 1)
        """
        self.cur.execute(sql)
        return [row for row in self.cur]
    
    def getUniqueUsernames(self):
        """
        Fetch all unique usernames from the 'users' table.
        """
        sql = "SELECT DISTINCT UserName FROM users WHERE role = 'customer'"
        self.cur.execute(sql)
        return [row['UserName'] for row in self.cur.fetchall()]
