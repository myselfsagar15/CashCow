from baseObject import baseObject
import datetime
class Dispute(baseObject):
    def __init__(self):
        super().__init__()  
        self.tn = "disputes"  
        self.data = []

    def getByTransactionID(self, transaction_id):
        sql = "SELECT * FROM disputes WHERE TransactionID = %s"
        self.cur.execute(sql, (transaction_id,))
        self.data = [row for row in self.cur]
        return self.data

    def createDispute(self, transaction_id, user_id, message):
        sql = """
            INSERT INTO disputes (TransactionID, UserID, Message, Status)
            VALUES (%s, %s, %s, 'Pending')
        """
        self.cur.execute(sql, (transaction_id, user_id, message))
        self.conn.commit()
        return True

    def getAllDisputes(self, status=None):
        if status:
            sql = "SELECT * FROM disputes WHERE Status = %s"
            self.cur.execute(sql, (status,))
        else:
            sql = "SELECT * FROM disputes"
            self.cur.execute(sql)
        self.data = [row for row in self.cur]
        return self.data

    def getPendingDisputes(self):
        sql = "SELECT * FROM disputes WHERE Status = 'Pending'"
        self.cur.execute(sql)
        return [row for row in self.cur]

    def updateDisputeStatus(self, dispute_id, new_status, admin_reply):
        query = """
            UPDATE disputes
            SET Status = %s, State = 'Closed', AdminReply = %s, DisputeClosedDate = %s
            WHERE DisputeID = %s
        """
        values = (new_status, admin_reply, datetime.now(), dispute_id)
        self.cur.execute(query, values)
        self.conn.commit()

    def getRecentByUser(self, username, limit=5):
        sql = """
            SELECT 
                t.TransactionID, t.SenderName, t.ReceiverName, t.AmountSent, t.Status, t.TransactionDate,
                d.Status AS DisputeStatus, d.AdminReply
            FROM transaction t
            LEFT JOIN disputes d ON t.TransactionID = d.TransactionID
            WHERE t.SenderName = %s OR t.ReceiverName = %s
            ORDER BY t.TransactionDate DESC
            LIMIT %s
        """
        self.cur.execute(sql, (username, username, limit))
        return self.cur.fetchall()
