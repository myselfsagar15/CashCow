import pymysql
import yaml
from pathlib import Path


CREATE TABLE users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Password VARCHAR(255) NOT NULL,
    MiddleName VARCHAR(100),
    Email VARCHAR(255) UNIQUE NOT NULL,
    FirstName VARCHAR(100) NOT NULL,
    LastName VARCHAR(100) NOT NULL,
    PhoneNumber VARCHAR(15) UNIQUE,
    Address VARCHAR(255),
    UserName VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE sources (
    SourceID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    Type VARCHAR(50),
    BankAccountNumber VARCHAR(20),
    RoutingNumber VARCHAR(20),
    CardNumber VARCHAR(16),
    CVV VARCHAR(4),
    Expiry DATE,
    FOREIGN KEY (UserID) REFERENCES users(UserID)
);

CREATE TABLE transfer (
    TransferID INT AUTO_INCREMENT PRIMARY KEY,
    TransactionID INT,
    SenderUserID INT,
    ReceiverUserID INT,
    TransferDate DATE,
    TransferAmount DECIMAL(10, 2),
    FOREIGN KEY (TransactionID) REFERENCES transaction(TransactionID),
    FOREIGN KEY (SenderUserID) REFERENCES users(UserID),
    FOREIGN KEY (ReceiverUserID) REFERENCES users(UserID)
);

CREATE TABLE transaction (
    TransactionID INT AUTO_INCREMENT PRIMARY KEY,
    SenderName VARCHAR(100),
    TransactionDate DATE,
    AmountSent DECIMAL(10, 2),
    ReceiverName VARCHAR(100),
    SenderAccNum VARCHAR(20),
    ReceiverAccNum VARCHAR(20),
    ReceiverCardNo VARCHAR(16),
    SenderCardNo VARCHAR(16),
    AmountReceived DECIMAL(10, 2),
    Status VARCHAR(20)
);
