from baseObject import baseObject

class Transaction(baseObject):
    def __init__(self):
        self.setup()

    def getRecentByUser(self, user_name, limit=5):
        """
        Fetch the most recent transactions for the user based on SenderName or ReceiverName.
        """
        sql = f"""
            SELECT 
                TransactionID, SenderName, ReceiverName, AmountSent, Status, TransactionDate
            FROM 
                `{self.tn}`
            WHERE 
                SenderName = %s OR ReceiverName = %s
            ORDER BY 
                TransactionID DESC
            LIMIT %s
        """
        print("Debug SQL:", sql)  
        print("Debug Parameters:", user_name, user_name, limit)  

        
        self.cur.execute(sql, (user_name, user_name, limit))
        self.data = []
        for row in self.cur:
            self.data.append(row)

        print("Fetched Transactions in Method:", self.data)  
        return self.data



    def getAllByUser(self, user_id, filters=None):
        """
        Fetch all transactions for a specific user with optional filters.
        """
        sql = f"SELECT * FROM `{self.tn}` WHERE `SenderName` = %s OR `ReceiverName` = %s"
        params = [user_id, user_id]

        
        if filters:
            if 'date' in filters and filters['date']:
                sql += " AND `TransactionDate` = %s"
                params.append(filters['date'])
            if 'amount' in filters and filters['amount']:
                sql += " AND `AmountSent` >= %s"
                params.append(filters['amount'])

        sql += " ORDER BY `TransactionDate` DESC"  
        self.cur.execute(sql, tuple(params))
        self.data = []
        for row in self.cur:
            self.data.append(row)
        return self.data
    def getRecentByUser(self, user_id, limit=5):
        sql = """
            SELECT 
                t.TransactionID, t.SenderName, t.ReceiverName, t.AmountSent, t.Status, t.TransactionDate,
                d.Status AS DisputeStatus
            FROM 
                transaction t
            LEFT JOIN 
                disputes d ON t.TransactionID = d.TransactionID
            WHERE 
                t.SenderName = %s OR t.ReceiverName = %s
            ORDER BY 
                t.TransactionDate DESC
            LIMIT %s
        """
        self.cur.execute(sql, (user_id, user_id, limit))
        self.data = self.cur.fetchall()
        return self.data

    def getTotalTransactions(self):
        sql = "SELECT COUNT(*) as TotalTransactions FROM transaction"
        self.cur.execute(sql)
        return self.cur.fetchone()['TotalTransactions']

    def getWeeklyTransactionCount(self):
        query = """
            SELECT WEEK(TransactionDate) AS Week, COUNT(*) AS Count
            FROM transaction
            GROUP BY WEEK(TransactionDate)
            ORDER BY Week
        """
        self.cur.execute(query)
        return self.cur.fetchall() 



