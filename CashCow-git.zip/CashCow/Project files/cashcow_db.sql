CREATE DATABASE  IF NOT EXISTS `cashcow_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `cashcow_db`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cashcow_db
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `UserID` int NOT NULL AUTO_INCREMENT,
  `Password` varchar(255) NOT NULL,
  `MiddleName` varchar(100) DEFAULT NULL,
  `Email` varchar(255) NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `PhoneNumber` varchar(15) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `role` varchar(50) DEFAULT 'customer',
  `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `UserName` (`UserName`),
  UNIQUE KEY `PhoneNumber` (`PhoneNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'a4eb2e0f3e0cbac5c3e64ddc4d24f1df',NULL,'sagar@gmail.com','sagar','bangera','53838','potsdam','sagar56','customer','2024-12-04 02:08:35'),(3,'0cecde91584725b9b1b4461a1f595f32',NULL,'ss@2','ss','ss','222','33','ss','customer','2024-12-04 02:08:35'),(4,'a4eb2e0f3e0cbac5c3e64ddc4d24f1df',NULL,'ash@gmail.com','ashish','juttu','12345','84B','juttuv','customer','2024-12-04 02:08:35'),(5,'81dc9bdb52d04dc20036dbd8313ed055',NULL,'jaya.cute5@gmail.com','jaya','shree','9320165150','Dombivili','jaya0505','customer','2024-12-04 02:08:35'),(6,'81dc9bdb52d04dc20036dbd8313ed055',NULL,'kanchan@gmail.com','karishma','anchan','3032873023','Virginia','karishma','customer','2024-12-04 02:08:35'),(7,'81dc9bdb52d04dc20036dbd8313ed055',NULL,'admin1@gmail.com','Admin1','Admin1','1234567890','CVP','admin1','admin','2024-12-04 02:08:35');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-10 19:49:56
-- Table structure for table `sources`
--

DROP TABLE IF EXISTS `sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sources` (
  `SourceID` int NOT NULL AUTO_INCREMENT,
  `UserID` int DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `BankAccountNumber` varchar(20) DEFAULT NULL,
  `RoutingNumber` varchar(20) DEFAULT NULL,
  `CardNumber` varchar(16) DEFAULT NULL,
  `CVV` varchar(4) DEFAULT NULL,
  `Expiry` date DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT '0.00',
  `IsPrimary` tinyint DEFAULT '0',
  PRIMARY KEY (`SourceID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `sources_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sources`
--

LOCK TABLES `sources` WRITE;
/*!40000 ALTER TABLE `sources` DISABLE KEYS */;
INSERT INTO `sources` VALUES (3,6,'Bank Account','5678','3456',NULL,NULL,NULL,5000.00,0),(4,5,'Card',NULL,NULL,'5555553','743','2028-09-01',0.00,0),(6,5,'Bank Account','444444','7844',NULL,NULL,NULL,0.00,0),(8,1,'Card',NULL,NULL,'6534333','855','2031-07-01',194.00,1),(11,1,'Bank Account','7542334','63343',NULL,NULL,NULL,899.00,NULL),(12,1,'Bank Account','0987652','435423',NULL,NULL,NULL,1306.00,NULL),(13,5,'Bank Account','8654333','876542',NULL,NULL,NULL,590.00,1),(14,5,'Card',NULL,NULL,'7654378','742','2034-12-01',900.00,0);
/*!40000 ALTER TABLE `sources` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-10 19:49:56

-- Table structure for table `disputes`
--

DROP TABLE IF EXISTS `disputes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disputes` (
  `DisputeID` int NOT NULL AUTO_INCREMENT,
  `TransactionID` int NOT NULL,
  `UserID` int NOT NULL,
  `Message` text NOT NULL,
  `Status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `State` enum('Open','Closed') DEFAULT 'Open',
  `AdminReply` text,
  `DisputeRaisedDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `DisputeClosedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`DisputeID`),
  KEY `TransactionID` (`TransactionID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `disputes_ibfk_1` FOREIGN KEY (`TransactionID`) REFERENCES `transaction` (`TransactionID`),
  CONSTRAINT `disputes_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disputes`
--

LOCK TABLES `disputes` WRITE;
/*!40000 ALTER TABLE `disputes` DISABLE KEYS */;
INSERT INTO `disputes` VALUES (1,5,5,'incorrect account','Approved','Open',NULL,'2024-12-10 15:41:21',NULL),(2,8,5,'duplicate','Rejected','Open',NULL,'2024-12-10 15:41:21',NULL),(3,1,5,'want to cancel','Approved','Open',NULL,'2024-12-10 15:41:21',NULL),(4,9,1,'just testing','Rejected','Closed','not vaid','2024-12-10 15:41:21','2024-12-10 15:50:55');
/*!40000 ALTER TABLE `disputes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-10 19:49:56

-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `TransactionID` int NOT NULL AUTO_INCREMENT,
  `SenderName` varchar(100) DEFAULT NULL,
  `TransactionDate` date DEFAULT NULL,
  `AmountSent` decimal(10,2) DEFAULT NULL,
  `ReceiverName` varchar(100) DEFAULT NULL,
  `SenderAccNum` varchar(20) DEFAULT NULL,
  `ReceiverAccNum` varchar(20) DEFAULT NULL,
  `ReceiverCardNo` varchar(16) DEFAULT NULL,
  `SenderCardNo` varchar(16) DEFAULT NULL,
  `AmountReceived` decimal(10,2) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`TransactionID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (1,'jaya0505','2024-11-27',23.00,'sagar56','1234',NULL,NULL,NULL,23.00,'Successful'),(2,'jaya0505','2024-11-27',1300.00,'sagar56','1234',NULL,NULL,NULL,1300.00,'Successful'),(3,'jaya0505','2024-11-27',4.00,'karishma',NULL,NULL,NULL,'5555553',4.00,'Successful'),(4,'jaya0505','2024-11-27',486.00,'karishma',NULL,NULL,NULL,'5555553',486.00,'Successful'),(5,'jaya0505','2024-11-27',5.00,'karishma','444444',NULL,NULL,NULL,5.00,'Successful'),(6,'jaya0505','2024-11-27',97.00,'karishma','444444',NULL,NULL,NULL,97.00,'Successful'),(7,'sagar56','2024-11-27',566.00,'jaya0505','57644',NULL,NULL,NULL,566.00,'Successful'),(8,'jaya0505','2024-12-03',100.00,'juttuv','444444',NULL,NULL,NULL,100.00,'Successful'),(9,'sagar56','2024-12-06',200.00,'jaya0505',NULL,NULL,NULL,'6534333',200.00,'Successful'),(10,'jaya0505','2024-12-06',2.00,'juttuv','8654333',NULL,NULL,NULL,2.00,'Successful'),(11,'jaya0505','2024-12-06',55.00,'sagar56','444444',NULL,NULL,NULL,55.00,'Successful'),(12,'jaya0505','2024-12-06',500.00,'sagar56','444444',NULL,NULL,NULL,500.00,'Successful'),(13,'jaya0505','2024-12-07',500.00,'sagar56',NULL,NULL,NULL,'5555553',500.00,'Successful'),(14,'jaya0505','2024-12-10',5.00,'karishma','8654333',NULL,NULL,NULL,5.00,'Successful');
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-10 19:49:57
