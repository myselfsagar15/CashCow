from baseObject import baseObject

class Transfer(baseObject):
    def __init__(self):
        self.setup()
